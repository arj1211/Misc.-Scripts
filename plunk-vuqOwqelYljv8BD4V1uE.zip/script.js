let suits = ['Hearts', 'Spades', 'Clubs', 'Diamonds'];
let vals = [
  'Ace', 'Two', 'Three',
  'Four', 'Five', 'Six',
  'Seven', 'Eight', 'Nine',
  'Ten', 'Jack', 'Queen', 'King'
];

let tArea = document.getElementById('tArea'),
  statArea = document.getElementById('stats'),
  startBtn = document.getElementById('start_btn'),
  hitBtn = document.getElementById('hit_btn'),
  stayBtn = document.getElementById('stay_btn');

function createDeck() {
  let deck = [];
  for (let i = 0; i < suits.length; i++) {
    for (let j = 0; j < vals.length; j++) {
      let card = {
        suit: suits[i],
        value: vals[j]
      }
      deck.push(card);
    }
  }
  return deck;
}

function getNextCard() {
  return deck.shift();
}

function getCardString(card) {
  return card.value + ' of ' + card.suit;
}

function getCardNumericalValue(card) {
  switch (card.value) {
    case 'Ace':
      return 1;
    case 'Two':
      return 2;
    case 'Three':
      return 3;
    case 'Four':
      return 4;
    case 'Five':
      return 5;
    case 'Six':
      return 6;
    case 'Seven':
      return 7;
    case 'Eight':
      return 8;
    case 'Nine':
      return 9;
    default:
      return 10; // jack==queen==king==10
  }
}

function getScore(hand) {
  let score = 0;
  let hasAce = false;

  for (let i = 0; i < hand.length; i++) {
    if (hand[i].value == 'Ace') {
      hasAce = true;
    }
    score += getCardNumericalValue(hand[i]);
  }

  if (hasAce && (score + 10) <= 21) {
    /* score+10 because 1 has been 
    added to score already for ace, 
    meaning a potential 11-1=10 points 
    are left to add to score if it is 
    beneficial to do so */
    score += 10;
  }

  return score;
}

function updateScores() {
  dealerScore = getScore(dealerCards);
  playerScore = getScore(playerCards);
}

function showStatus() {
  if (!gameStarted) {
    tArea.innerText = 'Click start to play!';
    return;
  }

  let dealerStr = '',
    playerStr = '';

  for (let i = 0; i < dealerCards.length; i++) {
    dealerStr += getCardString(dealerCards[i]) + '\n';
  }
  for (let j = 0; j < playerCards.length; j++) {
    playerStr += getCardString(playerCards[j]) + '\n';
  }

  updateScores();

  tArea.innerText =
    'Dealer has:\n' + dealerStr +
    '(score: ' + dealerScore + ')\n\n' +
    'Player has:\n' + playerStr + '(score: ' + playerScore + ')\n\n';

  if (gameOver) {
    if (winStatus == winStates.PLAYER) tArea.innerText += "Player wins!";
    else if (winStatus == winStates.DEALER) tArea.innerText += "Dealer wins.";
    else if (winStatus == winStates.TIE) tArea.innerText += "Tied!";
    startBtn.style.display = 'inline';
    hitBtn.style.display = 'none';
    stayBtn.style.display = 'none';
  }

}

function shuffleDeck(deck) {
  for (let i = 0; i < deck.length; i++) {
    let swapInd = Math.trunc(Math.random() * deck.length); //index of random card in deck
    let temp = deck[swapInd]; //that random card is held
    deck[swapInd] = deck[i]; //the current card is put in the random card's original place
    deck[i] = temp; //the random card is placed in the current card's original place
  }
}

function checkGameEnd() {
  updateScores();
  while (dealerScore < playerScore && (dealerScore * playerScore < 21 * 21)) {
    dealerCards.push(getNextCard());
    updateScores();
  }
  if (playerScore > 21) {
    winStatus = winStates.DEALER;
    //stats.dealerWins++;
    gameOver = true;
    stats.totalGames++;
  } else if (dealerScore > 21) {
    winStatus = winStates.PLAYER;
    //stats.playerWins++;
    gameOver = true;
    stats.totalGames++;
  } else if (playerScore>21 && dealerScore>21){
    winStatus = winStates.TIE;
    //stats.ties++;
    gameOver = true;
    stats.totalGames++;
  } else if (gameOver) {
    stats.totalGames++;
    winStatus = (playerScore > dealerScore) ? winStates.PLAYER : winStates.DEALER;
    winStatus = (playerScore == dealerScore) ? winStates.TIE : winStatus;
  }
  
  switch (winStatus) {
    case winStates.PLAYER:
      stats.playerWins++;
      break;
    case winStates.DEALER:
      stats.dealerWins++;
      break;
    case winStates.TIE:
      stats.ties++;
      break;
  }
  
  stats.playerWinFreq = (isNaN(stats.playerWins/stats.totalGames))?0:stats.playerWins/stats.totalGames;
  stats.dealerWinFreq = (isNaN(stats.dealerWins/stats.totalGames))?0:stats.dealerWins/stats.totalGames;
  stats.tieFreq = (isNaN(stats.ties/stats.totalGames))?0:stats.ties/stats.totalGames;
}

function displayStats() {
  statArea.innerText =
    '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~' +
    '\nPlayer Wins: ' + stats.playerWins +
    '\nDealer Wins: ' + stats.dealerWins +
    '\nTies: ' + stats.ties +
    '\nTotal Games: ' + stats.totalGames +  
    '\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n' +
    'Player Win Frequency: ' + Math.trunc(stats.playerWinFreq * 10000) / 100 + '%\n' +
    'Dealer Win Frequency: ' + Math.trunc(stats.dealerWinFreq * 10000) / 100 + '%\n' +
    'Tie Frequency: ' + Math.trunc(stats.tieFreq * 10000) / 100 + '%';
}

let gameStarted = false,
  gameOver = false,
  winStatus = -1,
  winStates = {
    PLAYER: 0,
    DEALER: 1,
    TIE: 2
  };
  dealerCards = [],
  playerCards = [],
  dealerScore = 0,
  playerScore = 0,
  deck = [];

let stats = {
  totalGames: 0,
  playerWins: 0,
  dealerWins: 0,
  ties: 0,
  playerWinFreq: 0.0,
  dealerWinFreq: 0.0,
  tieFreq: 0.0
};

hitBtn.style.display = 'none';
stayBtn.style.display = 'none';

startBtn.addEventListener('click', function() {
  startBtn.style.display = 'none';
  hitBtn.style.display = 'inline';
  stayBtn.style.display = 'inline';

  gameStarted = true;
  gameOver = false;
  winStatus = -1;
  deck = createDeck();
  shuffleDeck(deck);
  dealerCards = [getNextCard(), getNextCard()];
  playerCards = [getNextCard(), getNextCard()];
  checkGameEnd();
  showStatus();
  displayStats();
});
hitBtn.addEventListener('click', function() {
  playerCards.push(getNextCard());
  checkGameEnd();
  showStatus();
  displayStats();
});
stayBtn.addEventListener('click', function() {
  gameOver = true;
  checkGameEnd();
  showStatus();
  displayStats();
});